(* ::Package:: *)

(* Standalone pole-informed rational mapped-Chebyshev transport.
   This package does not load, patch, or call Alice-Shimada/CHESS. *)

BeginPackage["RationalCHESS`"];

$RationalCHESSVersion::usage = "$RationalCHESSVersion is the standalone package version string.";
RationalCHESSOptimizeMapPole::usage = "RationalCHESSOptimizeMapPole[singularities,{a,b}] selects a real Mobius-map pole outside the interval by maximizing the smallest mapped Bernstein parameter.";
RationalCHESSMapDiagnostics::usage = "RationalCHESSMapDiagnostics[singularities,{a,b},q] returns an Association describing the map and convergence geometry.";
RationalChebyshevLobattoData::usage = "RationalChebyshevLobattoData[n,{a,b},q,prec] returns n+1 mapped Lobatto nodes and their first-derivative matrix.";
RationalCHESSBuildDLogData::usage = "RationalCHESSBuildDLogData[Atilde] converts a matrix linear in logW[i] into a fixed sparse coefficient table.";
RationalCHESSDLogMatrix::usage = "RationalCHESSDLogMatrix[data,dlogValues,prec] assembles the sparse differential matrix from dlog letter values.";
RationalCHESSDLogOperator::usage = "RationalCHESSDLogOperator[data,dlogValues,prec] creates a matrix-free fixed-pattern operator for fast repeated matrix-vector products.";
RationalSpectralPropagate::usage = "RationalSpectralPropagate[B,y0,{a,b},opts] independently transports canonical epsilon coefficients. y0 is M by K and B[t] is M by M.";
RationalCHESSNodes::usage = "RationalCHESSNodes[result] returns the physical collocation nodes.";
RationalCHESSStateVectors::usage = "RationalCHESSStateVectors[result] returns one M by K coefficient matrix per node.";
RationalCHESSFinalState::usage = "RationalCHESSFinalState[result] returns the M by K coefficient matrix at the right endpoint.";
RationalCHESSDiagnostics::usage = "RationalCHESSDiagnostics[result] returns map and solve diagnostics.";
RationalCHESSClearCaches::usage = "RationalCHESSClearCaches[] clears map and collocation caches.";
RationalCHESSCacheInfo::usage = "RationalCHESSCacheInfo[] reports cache entry counts.";

Begin["`Private`"];

$RationalCHESSVersion = "0.3.0-standalone";
$mapCache = <||>;
$collocationCache = <||>;

RationalCHESSOptimizeMapPole::interval = "The interval `1` must contain two finite real numbers in increasing order.";
RationalCHESSOptimizeMapPole::sing = "At least one finite singularity, or InfinitySingularity -> True, is required.";
RationalCHESSOptimizeMapPole::onpath = "The singularities `1` lie on the transport interval `2`.";
RationalChebyshevLobattoData::pole = "The map pole `1` must be finite, real, and outside `2`.";
RationalChebyshevLobattoData::grid = "The mapped grid failed endpoint, finiteness, or monotonicity validation.";
RationalSpectralPropagate::y0 = "y0 must be a nonempty rectangular M by K numeric matrix.";
RationalSpectralPropagate::matrix = "B(t) at node `1` is not a numeric `2` by `2` matrix.";
RationalSpectralPropagate::solve = "The scalar collocation solve failed at epsilon coefficient `1`.";
RationalSpectralPropagate::reg = "Only left-endpoint regularization is currently supported.";
RationalSpectralPropagate::regdata = "LeftEndpointOperator must be {residue,finitePart}, with two numeric `1` by `1` matrices.";
RationalCHESSBuildDLogData::linear = "Atilde entry `1` is not linear in the logW slots.";
RationalCHESSDLogMatrix::slots = "The dlog value list has length `1`, but slot `2` is required.";

ClearAll[validIntervalQ];
validIntervalQ[{a_, b_}] := And[
  NumberQ[N[a]], NumberQ[N[b]], Im[N[a]] == 0, Im[N[b]] == 0, TrueQ[a < b]
];

(* Normalize physical coordinates before mapping.  This avoids cancellation in
   the alpha/beta representation when the map pole is far from the interval. *)
ClearAll[normalizedMapPole, normalizedPhysicalPoint, mappedPoint];
normalizedMapPole[q_, {a_, b_}] := (q - (a + b)/2)/((b - a)/2);
normalizedPhysicalPoint[p_, {a_, b_}] := (p - (a + b)/2)/((b - a)/2);

mappedPoint[p_, q_, interval_] := Module[{qq, ss, dq},
  qq = normalizedMapPole[q, interval];
  ss = normalizedPhysicalPoint[p, interval];
  dq = Quiet @ N[ss - qq, 40];
  If[
    NumberQ[dq] && Abs[dq] < 10^-28 Max[1, Abs[N[qq, 40]]],
    Infinity,
    If[Abs[N[qq]] > 2, (ss - 1/qq)/(1 - ss/qq), (qq ss - 1)/(qq - ss)]
  ]
];

ClearAll[bernsteinRho];
bernsteinRho[Infinity] := Infinity;
bernsteinRho[ComplexInfinity] := Infinity;
bernsteinRho[z_] := Module[{zz, w, aw},
  zz = Quiet @ N[z, 50];
  If[!NumberQ[zz], Return[Infinity]];
  w = zz + Sqrt[zz - 1] Sqrt[zz + 1];
  aw = Abs[w];
  If[PossibleZeroQ[aw], Infinity, Max[aw, 1/aw]]
];

ClearAll[mapScore];
mapScore[q_?NumericQ, singularities_List, interval_, infinitySingularity_] := Module[
  {images, qnormalized},
  images = mappedPoint[#, q, interval] & /@ singularities;
  If[TrueQ[infinitySingularity],
    qnormalized = normalizedMapPole[q, interval];
    images = Append[images, -qnormalized]
  ];
  Min[bernsteinRho /@ images]
];

Options[RationalCHESSOptimizeMapPole] = {
  "InfinitySingularity" -> False,
  "Samples" -> 160,
  "Refinements" -> 5,
  "SearchScale" -> 64
};

RationalCHESSOptimizeMapPole[
    singularities_List,
    interval : {a_?NumericQ, b_?NumericQ},
    OptionsPattern[]
  ] := Module[
  {
    infQ = TrueQ[OptionValue["InfinitySingularity"]],
    samples = Max[16, Round[OptionValue["Samples"]]],
    refs = Max[1, Round[OptionValue["Refinements"]]],
    searchScale = Max[2, N[OptionValue["SearchScale"]]],
    finite, onPath, key, mid, scale, minDistance, maxDistance,
    logRange, bestOnSide, bests, answer
  },
  If[!validIntervalQ[interval],
    Message[RationalCHESSOptimizeMapPole::interval, interval]; Return[$Failed]
  ];
  finite = Select[singularities, NumberQ[Quiet @ N[#, 30]] &];
  If[finite === {} && !infQ,
    Message[RationalCHESSOptimizeMapPole::sing]; Return[$Failed]
  ];
  onPath = Select[finite, TrueQ[a <= Re[N[#]] <= b] && PossibleZeroQ[Im[N[#]]] &];
  If[onPath =!= {},
    Message[RationalCHESSOptimizeMapPole::onpath, onPath, interval]; Return[$Failed]
  ];

  key = Hash[{N[finite, 24], N[interval, 24], infQ, samples, refs, searchScale}];
  If[KeyExistsQ[$mapCache, key], Return[$mapCache[key]]];

  mid = (a + b)/2;
  scale = Max[
    N[Abs[b - a]],
    If[finite === {}, 1., Max[Abs[N[# - mid]] & /@ finite]],
    1.*^-6
  ];
  minDistance = 10^-10 scale;
  maxDistance = searchScale scale;
  logRange = Log[{minDistance, maxDistance}];

  (* Search log(distance-to-endpoint), resolving both near-endpoint optima and
     the far-pole/polynomial limit better than a uniform q grid. *)
  bestOnSide[side_] := Module[
    {lo, hi, grid, qs, values, idx, width, u0, iter},
    {lo, hi} = logRange;
    u0 = (lo + hi)/2;
    Do[
      grid = N[Subdivide[lo, hi, samples], 40];
      qs = If[side < 0, a - Exp[grid], b + Exp[grid]];
      values = mapScore[#, finite, interval, infQ] & /@ qs;
      idx = First @ Ordering[values, -1];
      u0 = grid[[idx]];
      width = (hi - lo)/samples;
      lo = Max[First[logRange], u0 - width];
      hi = Min[Last[logRange], u0 + width],
      {iter, refs}
    ];
    With[{q0 = If[side < 0, a - Exp[u0], b + Exp[u0]]},
      {q0, mapScore[q0, finite, interval, infQ]}
    ]
  ];

  bests = bestOnSide /@ {-1, 1};
  answer = First @ First @ MaximalBy[bests, Last];
  $mapCache[key] = answer
];

RationalCHESSMapDiagnostics[
    singularities_List,
    interval : {a_?NumericQ, b_?NumericQ},
    q_?NumericQ,
    infinitySingularity_: False
  ] := Module[{images, rhos, qq},
  qq = normalizedMapPole[q, interval];
  images = mappedPoint[#, q, interval] & /@ singularities;
  If[TrueQ[infinitySingularity], images = Append[images, -qq]];
  rhos = bernsteinRho /@ images;
  <|
    "MapPole" -> q,
    "NormalizedMapPole" -> qq,
    "MappedSingularities" -> images,
    "BernsteinRhos" -> rhos,
    "MinimumBernsteinRho" -> Min[rhos],
    "InfinityIncluded" -> TrueQ[infinitySingularity]
  |>
];

(* Store one sparse coefficient matrix on the nonzero-value index rather than
   one 734x734 sparse matrix per letter.  Node evaluation is then a single
   sparse matrix-vector product plus construction with fixed positions. *)
RationalCHESSBuildDLogData[raw_] := Module[
  {
    normalized, sparse, dims, rules, positions, expressions, slots, slotLookup,
    coefficientRules, row, expr, exprVars, pair, coefficientMatrix,
    rowIndices, columnIndices, rowAccumulator
  },
  normalized = raw /. (
    (head_[i_Integer] /; SymbolName[Unevaluated[head]] === "logW") :> logW[i]
  );
  sparse = SparseArray[normalized];
  dims = Dimensions[sparse];
  If[Length[dims] != 2, Return[$Failed]];
  rules = Most[ArrayRules[sparse]];
  positions = rules[[All, 1]];
  expressions = rules[[All, 2]];
  slots = Sort @ DeleteDuplicates @ Cases[expressions, logW[i_Integer] :> i, Infinity];
  slotLookup = ConstantArray[0, If[slots === {}, 0, Max[slots]]];
  If[slots =!= {}, slotLookup[[slots]] = Range[Length[slots]]];

  coefficientRules = Reap[
    Do[
      expr = expressions[[row]];
      exprVars = DeleteDuplicates @ Cases[
        expr, lw : logW[i_Integer] :> {i, lw}, {0, Infinity}
      ];
      Do[
        pair = exprVars[[j]];
        Sow[{row, slotLookup[[pair[[1]]]]} -> Coefficient[expr, pair[[2]]]],
        {j, Length[exprVars]}
      ];
      If[!PossibleZeroQ[expr /. _logW -> 0],
        Message[RationalCHESSBuildDLogData::linear, positions[[row]]];
        Return[$Failed]
      ],
      {row, Length[expressions]}
    ]
  ][[2]];
  coefficientRules = If[coefficientRules === {}, {}, First[coefficientRules]];
  coefficientMatrix = SparseArray[
    coefficientRules,
    {Length[expressions], Length[slots]}
  ];
  rowIndices = positions[[All, 1]];
  columnIndices = positions[[All, 2]];
  rowAccumulator = SparseArray[
    Thread[Transpose[{rowIndices, Range[Length[rowIndices]]}] -> 1],
    {First[dims], Length[rowIndices]}
  ];
  <|
    "Dimensions" -> dims,
    "Slots" -> slots,
    "Positions" -> positions,
    "CoefficientMatrix" -> coefficientMatrix,
    "Columns" -> columnIndices,
    "RowAccumulator" -> rowAccumulator
  |>
];

ClearAll[dlogEntryValues];
dlogEntryValues[data_Association, dlogValues_List, prec_] := Module[
  {slots, coefficients},
  slots = data["Slots"];
  coefficients = data["CoefficientMatrix"];
  If[slots =!= {} && Length[dlogValues] < Max[slots],
    Message[RationalCHESSDLogMatrix::slots, Length[dlogValues], Max[slots]];
    Return[$Failed]
  ];
  N[coefficients . N[dlogValues[[slots]], prec], prec]
];

RationalCHESSDLogMatrix[data_Association, dlogValues_List, prec_ : MachinePrecision] := Module[
  {dims, positions, nonzeroValues},
  dims = data["Dimensions"];
  positions = data["Positions"];
  nonzeroValues = dlogEntryValues[data, dlogValues, prec];
  If[nonzeroValues === $Failed, Return[$Failed]];
  SparseArray[MapThread[Rule, {positions, nonzeroValues}], dims]
];

RationalCHESSDLogOperator[data_Association, dlogValues_List, prec_ : MachinePrecision] := Module[
  {nonzeroValues},
  nonzeroValues = dlogEntryValues[data, dlogValues, prec];
  If[nonzeroValues === $Failed, Return[$Failed]];
  <|
    "RationalCHESSOperator" -> True,
    "Dimensions" -> data["Dimensions"],
    "EntryValues" -> nonzeroValues,
    "Columns" -> data["Columns"],
    "RowAccumulator" -> data["RowAccumulator"]
  |>
];

ClearAll[chebyshevLobattoData];
chebyshevLobattoData[n_Integer?Positive, prec_] := Module[
  {x, weights, differences, d},
  x = N[-Cos[Pi Range[0, n]/n], prec];
  weights = N[Table[(-1)^j If[j == 0 || j == n, 1/2, 1], {j, 0, n}], prec];
  differences = Outer[Subtract, x, x];
  d = Outer[Times, 1/weights, weights]/(differences + IdentityMatrix[n + 1]);
  d = d - DiagonalMatrix[Total[d, {2}]];
  {x, d}
];

RationalChebyshevLobattoData[
    n_Integer?Positive,
    interval : {a_?NumericQ, b_?NumericQ},
    q_?NumericQ,
    prec_ : MachinePrecision
  ] := Module[
  {key, y, dy, qq, half, aa, bb, qWork, sNodes, nodes, dydt, data, tol},
  If[!validIntervalQ[interval] || Im[N[q]] != 0 || TrueQ[a <= q <= b],
    Message[RationalChebyshevLobattoData::pole, q, interval]; Return[$Failed]
  ];
  key = Hash[{n, N[interval, 24], N[q, 24], prec}];
  If[KeyExistsQ[$collocationCache, key], Return[$collocationCache[key]]];

  {y, dy} = chebyshevLobattoData[n, prec];
  (* N[machineReal,p] cannot restore precision and would contaminate the whole
     arbitrary-precision grid.  The pole is a chosen basis parameter, so pad
     its stored value to the requested arithmetic precision before use. *)
  {aa, bb, qWork} = If[
    prec === MachinePrecision,
    N[{a, b, q}],
    SetPrecision[{a, b, q}, prec]
  ];
  half = (bb - aa)/2;
  qq = (qWork - (aa + bb)/2)/half;
  sNodes = If[Abs[N[qq]] > 2, (y + 1/qq)/(1 + y/qq), (qq y + 1)/(qq + y)];
  nodes = N[(aa + bb)/2 + half sNodes, prec];
  dydt = N[(1 - 1/qq^2)/(half (1 - sNodes/qq)^2), prec];
  data = {nodes, MapThread[Times, {dydt, dy}]};

  tol = If[prec === MachinePrecision, 10^-11, 10^(-Max[12, Floor[prec/2]])];
  If[
    !FreeQ[nodes, Indeterminate | ComplexInfinity | _DirectedInfinity] ||
      !And @@ Thread[Differences[N[nodes]] > 0] ||
      Abs[N[First[nodes] - a]] > tol Max[1, Abs[N[a]]] ||
      Abs[N[Last[nodes] - b]] > tol Max[1, Abs[N[b]]],
    Message[RationalChebyshevLobattoData::grid]; Return[$Failed]
  ];
  $collocationCache[key] = data
];

ClearAll[evaluateMatrix];
evaluateMatrix[nAfun_, x_, prec_] := Module[{value},
  value = Quiet @ Check[nAfun[x, "Precision" -> prec], $Failed];
  If[value === $Failed, value = Quiet @ Check[nAfun[x], $Failed]];
  If[value === $Failed, Return[$Failed]];
  If[AssociationQ[value], value, N[value, prec]]
];

ClearAll[validNodeOperatorQ, applyNodeOperator];
validNodeOperatorQ[operator_, n_] := Or[
  MatrixQ[operator, NumericQ] && Dimensions[operator] === {n, n},
  AssociationQ[operator] &&
    TrueQ[Lookup[operator, "RationalCHESSOperator", False]] &&
    Lookup[operator, "Dimensions", {}] === {n, n} &&
    VectorQ[Lookup[operator, "EntryValues", {}], NumericQ]
];

applyNodeOperator[operator_Association, vector_] :=
  operator["RowAccumulator"] . (
    operator["EntryValues"] vector[[operator["Columns"]]]
  );
applyNodeOperator[operator_, vector_] := operator . vector;

Options[RationalSpectralPropagate] = {
  "Nodes" -> 48,
  "Precision" -> MachinePrecision,
  "WorkingPrecisionA" -> Automatic,
  "LinearSolverMethod" -> Automatic,
  "Singularities" -> {},
  "MapPole" -> Automatic,
  "InfinitySingularity" -> False,
  "MapSearchSamples" -> 160,
  "MapSearchRefinements" -> 5,
  "MapSearchScale" -> 64,
  "RegularizedEndpoints" -> {},
  "LeftEndpointOperator" -> Automatic,
  "ParallelEvaluation" -> False,
  "ParallelKernels" -> 1
};

RationalSpectralPropagate[
    nAfun_, y0_, interval : {a_?NumericQ, b_?NumericQ}, OptionsPattern[]
  ] := Module[
  {
    nNodes, prec, precA, method, singularities, infQ, q, collocation,
    nodes, derivMat, initial, dims, nMasters, nCoefficients, nodeMatrices,
    base, solver, zero, coeffSolutions, rhs, solution, coeff, j,
    finalState, nodeStates, mapDiagnostics, timings, regularizedEndpoints,
    leftRegularized, leftOperator, residue, finitePart, regularityResiduals,
    endpointSource, offset, value, power
  },
  regularizedEndpoints = OptionValue["RegularizedEndpoints"];
  leftRegularized = MemberQ[
    Flatten @ {regularizedEndpoints},
    "Left" | a
  ];
  If[regularizedEndpoints =!= {} && !leftRegularized,
    Message[RationalSpectralPropagate::reg]; Return[$Failed]
  ];
  nNodes = Max[1, Round[OptionValue["Nodes"]]];
  prec = OptionValue["Precision"];
  precA = Replace[OptionValue["WorkingPrecisionA"], Automatic -> prec];
  method = OptionValue["LinearSolverMethod"];
  singularities = OptionValue["Singularities"];
  infQ = TrueQ[OptionValue["InfinitySingularity"]];
  q = OptionValue["MapPole"];

  If[q === Automatic,
    q = RationalCHESSOptimizeMapPole[
      singularities, interval,
      "InfinitySingularity" -> infQ,
      "Samples" -> OptionValue["MapSearchSamples"],
      "Refinements" -> OptionValue["MapSearchRefinements"],
      "SearchScale" -> OptionValue["MapSearchScale"]
    ]
  ];
  If[q === $Failed, Return[$Failed]];

  initial = Quiet @ Check[N[y0, prec], $Failed];
  If[initial === $Failed || !MatrixQ[initial, NumericQ] || Length[initial] == 0 || Length[First[initial]] == 0,
    Message[RationalSpectralPropagate::y0]; Return[$Failed]
  ];
  dims = Dimensions[initial];
  {nMasters, nCoefficients} = dims;
  leftOperator = OptionValue["LeftEndpointOperator"];
  If[leftRegularized,
    If[
      !MatchQ[leftOperator, {_?MatrixQ, _?MatrixQ}] ||
        Dimensions[leftOperator[[1]]] =!= {nMasters, nMasters} ||
        Dimensions[leftOperator[[2]]] =!= {nMasters, nMasters} ||
        !MatrixQ[leftOperator[[1]], NumericQ] || !MatrixQ[leftOperator[[2]], NumericQ],
      Message[RationalSpectralPropagate::regdata, nMasters]; Return[$Failed]
    ];
    {residue, finitePart} = N[leftOperator, precA];
    regularityResiduals = If[nCoefficients > 1,
      Table[Norm[residue . initial[[All, coeff]]], {coeff, 1, nCoefficients - 1}],
      {}
    ],
    regularityResiduals = {}
  ];

  timings = Association[];
  timings["Grid"] = First @ AbsoluteTiming[
    collocation = RationalChebyshevLobattoData[nNodes, interval, q, prec]
  ];
  If[collocation === $Failed, Return[$Failed]];
  {nodes, derivMat} = collocation;

  (* The left endpoint is a boundary row, so B(a) is never evaluated. *)
  timings["MatrixEvaluation"] = First @ AbsoluteTiming[
    nodeMatrices = evaluateMatrix[nAfun, #, precA] & /@ Rest[nodes]
  ];
  Do[
    If[nodeMatrices[[j]] === $Failed || !validNodeOperatorQ[nodeMatrices[[j]], nMasters],
      Message[RationalSpectralPropagate::matrix, nodes[[j + 1]], nMasters]; Return[$Failed]
    ],
    {j, Length[nodeMatrices]}
  ];

  base = N[
    If[leftRegularized,
      IdentityMatrix[nNodes + 1] + DiagonalMatrix[nodes - a] . derivMat,
      derivMat
    ],
    prec
  ];
  If[!leftRegularized,
    base[[1, All]] = 0;
    base[[1, 1]] = 1
  ];
  solver = If[method === Automatic,
    Quiet @ Check[LinearSolve[base], $Failed],
    Quiet @ Check[LinearSolve[base, Method -> method], $Failed]
  ];
  If[Head[solver] =!= LinearSolveFunction, Return[$Failed]];

  zero = If[prec === MachinePrecision, 0., SetPrecision[0, prec]];
  coeffSolutions = ConstantArray[zero, {nCoefficients, nNodes + 1, nMasters}];
  timings["SequentialSolve"] = First @ AbsoluteTiming[
    Do[
      rhs = ConstantArray[zero, {nNodes + 1, nMasters}];
      If[leftRegularized,
        If[coeff > 1,
          endpointSource = ConstantArray[zero, nMasters];
          Do[
            value = finitePart . coeffSolutions[[coeff - offset, 1]];
            Do[value = residue . value, {power, 1, offset - 1}];
            endpointSource = endpointSource + value,
            {offset, 1, coeff - 1}
          ];
          rhs[[1]] = endpointSource;
          Do[
            rhs[[j]] = applyNodeOperator[
              nodeMatrices[[j - 1]], coeffSolutions[[coeff - 1, j]]
            ],
            {j, 2, nNodes + 1}
          ]
        ],
        rhs[[1]] = initial[[All, coeff]];
        If[coeff > 1,
          Do[
            rhs[[j]] = applyNodeOperator[
              nodeMatrices[[j - 1]], coeffSolutions[[coeff - 1, j]]
            ],
            {j, 2, nNodes + 1}
          ]
        ]
      ];
      solution = Quiet @ Check[solver[N[rhs, prec]], $Failed];
      If[solution === $Failed || Dimensions[solution] =!= {nNodes + 1, nMasters},
        Message[RationalSpectralPropagate::solve, coeff]; Return[$Failed]
      ];
      coeffSolutions[[coeff]] = If[
        leftRegularized,
        Table[
          initial[[All, coeff]] + (nodes[[j]] - a) solution[[j]],
          {j, nNodes + 1}
        ],
        solution
      ],
      {coeff, 1, nCoefficients}
    ]
  ];

  finalState = Transpose[coeffSolutions[[All, -1]]];
  nodeStates = Table[Transpose[coeffSolutions[[All, j]]], {j, nNodes + 1}];
  mapDiagnostics = RationalCHESSMapDiagnostics[singularities, interval, q, infQ];
  <|
    "Nodes" -> nodes,
    "StateVectors" -> nodeStates,
    "FinalState" -> finalState,
    "Diagnostics" -> <|
      "Method" -> "StandaloneSequentialEpsilonRationalMappedChebyshev",
      "Version" -> $RationalCHESSVersion,
      "Order" -> nNodes,
      "GridPointCount" -> nNodes + 1,
      "MasterCount" -> nMasters,
      "EpsilonCoefficientCount" -> nCoefficients,
      "LeftEndpointRegularized" -> leftRegularized,
      "LeftRegularityResiduals" -> regularityResiduals,
      "Map" -> mapDiagnostics,
      "TimingsSeconds" -> timings
    |>
  |>
];

RationalCHESSNodes[result_Association] := Lookup[result, "Nodes", $Failed];
RationalCHESSStateVectors[result_Association] := Lookup[result, "StateVectors", $Failed];
RationalCHESSFinalState[result_Association] := Lookup[result, "FinalState", $Failed];
RationalCHESSDiagnostics[result_Association] := Lookup[result, "Diagnostics", $Failed];

RationalCHESSClearCaches[] := ($mapCache = <||>; $collocationCache = <||>; Null);
RationalCHESSCacheInfo[] := <|"MapEntries" -> Length[$mapCache], "CollocationEntries" -> Length[$collocationCache]|>;

End[];
EndPackage[];
