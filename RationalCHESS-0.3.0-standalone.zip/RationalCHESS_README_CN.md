# RationalCHESS 使用说明

## 1. 程序简介

`RationalCHESS.wl` 是一个独立实现的 pole-informed rational spectral
微分方程传播程序，不加载、修改或调用 CHESS。当前版本为：

```text
0.3.0-standalone
```

它用于求解 canonical 微分方程

```text
dF(t,epsilon)/dt = epsilon B(t) F(t,epsilon)
```

并按 epsilon 系数逐阶传播：

```text
F(t,epsilon) = Sum[epsilon^k F_k(t), {k,kmin,kmax}].
```

主要功能包括：

- rational mapped-Chebyshev 配点；
- 根据复 t 平面奇点自动优化映射极点；
- sequential-epsilon 求解，避免一次构造大型块矩阵；
- 固定稀疏模式 dlog 矩阵装配；
- matrix-free 矩阵向量乘法；
- 左端点正则化；
- 机器精度和任意精度计算；
- 映射与配点网格缓存。

## 2. 环境与加载

本版本已在 Wolfram Engine 12.3.1 下测试。将
`RationalCHESS.wl` 放在当前工作目录，然后执行：

```wl
Get["RationalCHESS.wl"];
Needs["RationalCHESS`"];
```

检查版本：

```wl
$RationalCHESSVersion
```

预期输出：

```text
0.3.0-standalone
```

## 3. 最小示例

下面求解常矩阵 canonical 系统。边界矩阵 `y0` 的行对应 master，列对应
连续的 epsilon 系数。

```wl
Get["RationalCHESS.wl"];
Needs["RationalCHESS`"];

Options[bmat] = {"Precision" -> MachinePrecision};
b0 = {{1, 2}, {0, -1}};
bmat[x_?NumericQ, OptionsPattern[]] :=
  N[b0, OptionValue["Precision"]];

y0 = ConstantArray[0., {2, 5}];
y0[[All, 1]] = {1., -1.};

result = RationalSpectralPropagate[
  bmat,
  y0,
  {0., 1.},
  "MapPole" -> 2.,
  "Nodes" -> 28,
  "Precision" -> MachinePrecision
];

final = RationalCHESSFinalState[result];
diagnostics = RationalCHESSDiagnostics[result];
```

这里 `"Nodes" -> n` 表示谱阶数为 `n`，实际配点数为 `n+1`。
`"MapPole"` 必须位于传播区间之外。

## 4. 自动选择 rational map

如果已知拉回到 t 平面的奇点位置，可以让程序自动选择映射极点：

```wl
singularities = {1.03, 1.45, -2.1, 0.4 + 0.7 I};

q = RationalCHESSOptimizeMapPole[
  singularities,
  {0., 1.},
  "InfinitySingularity" -> True
];

mapInfo = RationalCHESSMapDiagnostics[
  singularities, {0., 1.}, q, True
];
```

也可以直接在传播函数中使用自动模式：

```wl
result = RationalSpectralPropagate[
  bmat, y0, {0., 1.},
  "Nodes" -> 28,
  "Singularities" -> singularities,
  "MapPole" -> Automatic,
  "InfinitySingularity" -> True
];
```

奇点不能位于开放传播区间内部。`mapInfo["MinimumBernsteinRho"]` 越大，
通常表示映射后的几何收敛率越好。

## 5. dlog 微分方程接口

对于

```text
Atilde = Sum[A_i logW[i], i]
B(t)  = Sum[A_i dlog(W_i(t)), i]
```

先将符号矩阵转换成固定稀疏模式：

```wl
dlogData = RationalCHESSBuildDLogData[Atilde];
```

若某一点的 dlog 值为：

```wl
dlogValues = Table[dlogExpressions[[i]] /. t -> x, {i, nLetters}];
```

可以组装完整稀疏矩阵：

```wl
B = RationalCHESSDLogMatrix[dlogData, dlogValues, MachinePrecision];
```

大系统建议使用 matrix-free operator：

```wl
Options[bOperator] = {"Precision" -> MachinePrecision};

bOperator[x_?NumericQ, OptionsPattern[]] := Module[
  {p = OptionValue["Precision"], values},
  values = N[dlogExpressions /. t -> N[x, p], p];
  RationalCHESSDLogOperator[dlogData, values, p]
];

result = RationalSpectralPropagate[
  bOperator, y0, {0., 1.},
  "Nodes" -> 24,
  "Singularities" -> singularities,
  "MapPole" -> Automatic,
  "InfinitySingularity" -> True
];
```

`logW[i]` 的编号是 positional slot：传入的 `dlogValues[[i]]` 必须对应
`dlog(W_i)`。

## 6. 左端点正则化

若左端点 `t=a` 附近

```text
B(t) = R/(t-a) + F + O(t-a),
```

则提供留数矩阵 `R` 和有限部分 `F`：

```wl
result = RationalSpectralPropagate[
  bOperator, y0, {a, b},
  "Nodes" -> 24,
  "MapPole" -> q,
  "RegularizedEndpoints" -> {"Left"},
  "LeftEndpointOperator" -> {R, F}
];
```

输入边界必须满足相应的正则条件。可检查：

```wl
RationalCHESSDiagnostics[result]["LeftRegularityResiduals"]
```

当前版本只实现左端点正则化。

## 7. 任意精度计算

```wl
result50 = RationalSpectralPropagate[
  bOperator,
  N[y0, 50],
  {0, 1},
  "Nodes" -> 30,
  "Precision" -> 50,
  "WorkingPrecisionA" -> 50,
  "Singularities" -> N[singularities, 50],
  "MapPole" -> Automatic,
  "InfinitySingularity" -> True
];
```

注意：如果原始输入已经是机器精度小数，`N[input,50]` 不能恢复丢失的
有效数字。高精度计算应尽量从整数、有理数或真正的高精度输入开始。

## 8. 主要选项

| 选项 | 默认值 | 说明 |
|---|---:|---|
| `"Nodes"` | `48` | 谱阶数；网格包含 `Nodes+1` 个点 |
| `"Precision"` | `MachinePrecision` | 网格和求解精度 |
| `"WorkingPrecisionA"` | `Automatic` | 微分矩阵或 operator 的计算精度 |
| `"Singularities"` | `{}` | 拉回到 t 平面的有限奇点 |
| `"MapPole"` | `Automatic` | rational map 极点；必须在区间外 |
| `"InfinitySingularity"` | `False` | 优化时是否把无穷远视为奇点 |
| `"LinearSolverMethod"` | `Automatic` | 传给 `LinearSolve` 的方法 |
| `"RegularizedEndpoints"` | `{}` | 当前支持 `{"Left"}` |
| `"LeftEndpointOperator"` | `Automatic` | 左端点的 `{R,F}` |
| `"ParallelEvaluation"` | `False` | 当前独立核心保留的并行接口 |
| `"ParallelKernels"` | `1` | 并行 kernel 数接口 |

自动 map 搜索还可通过 `"MapSearchSamples"`、
`"MapSearchRefinements"` 和 `"MapSearchScale"` 调整。

## 9. 返回结果

`RationalSpectralPropagate` 返回一个 Association。推荐使用：

```wl
RationalCHESSNodes[result]          (* 物理 t 网格 *)
RationalCHESSStateVectors[result]   (* 每个节点的 M x K 系数矩阵 *)
RationalCHESSFinalState[result]     (* 终点的 M x K 系数矩阵 *)
RationalCHESSDiagnostics[result]    (* map、维数、误差残量和计时 *)
```

缓存管理：

```wl
RationalCHESSCacheInfo[]
RationalCHESSClearCaches[]
```

## 10. 收敛与误差检查建议

不要只运行一个阶数。建议计算嵌套序列，例如：

```wl
orders = {12, 16, 20};
solutions = RationalCHESSFinalState[
  RationalSpectralPropagate[
    bOperator, y0, {0., 1.},
    "Nodes" -> #,
    "Singularities" -> singularities,
    "MapPole" -> Automatic,
    "InfinitySingularity" -> True
  ]
] & /@ orders;

nestedError = Norm[Flatten[solutions[[-1]] - solutions[[-2]]]]/
  Max[1, Norm[Flatten[solutions[[-1]]]]];
```

对强奇点问题还应检查：

- 奇点是否误落在传播路径上；
- 起点正则残量是否足够小；
- 提高精度后误差地板是否下降；
- 不同阶数或独立求解器的高阶结果是否一致。

## 11. 独立性与适用范围

本程序是 Rational Spectral 方法的独立实现。CHESS 只在外部 benchmark
中作为竞争程序使用，`RationalCHESS.wl` 本身不依赖 CHESS。

当前限制：

- canonical 系统采用逐 epsilon 系数传播；
- 输入边界必须是非空的 `M x K` 数值矩阵；
- 当前仅支持左端点正则化；
- 用户需要提供 t 平面的奇点候选，或显式指定区间外的 map pole；
- 生产计算应通过阶数递增和精度递增自行验证收敛。

## 12. 文件校验

发行包内的 `SHA256SUMS.txt` 用于确认程序和说明文件未被修改。在 Linux
下可运行：

```bash
sha256sum -c SHA256SUMS.txt
```
